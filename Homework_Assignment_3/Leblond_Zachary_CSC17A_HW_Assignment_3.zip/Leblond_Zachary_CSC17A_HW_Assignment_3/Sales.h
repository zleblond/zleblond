#ifndef SALES_H
#define SALES_H
struct Sales {
    string name;
    //First - Fourth Quarter Sales
    int first, second, third, fourth, total;
    float average;
        
};

#endif /* SALES_H */

