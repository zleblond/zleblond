/* 
 * File:   Soccer.h
 * Author: Zachary Leblond
 *
 * Created on October 3, 2017, 5:01 PM
 */

#ifndef SOCCER_H
#define SOCCER_H

struct Soccer {
string name;
int number;
int points;

};

#endif /* SOCCER_H */

