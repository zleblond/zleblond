/* 
 * File:   Company.h
 * Author: Zachary Leblond
 *
 * Created on October 11, 2017, 4:43 PM
 */

#ifndef COMPANY_H
#define COMPANY_H

struct Company
{
    string name;
    int quarter[4];
    float sales[4];
};

#endif /* COMPANY_H */

