
#ifndef TESTSCORES_H
#define TESTSCORES_H
const int size=5;
class TestScores 
{
    int scores[20];
public:
    class InvalidScore
    { };
    TestScores(int []);
    float average(int[]);
};



#endif /* TESTSCORES_H */

TestScores::TestScores(int score[])
{
    for(int i=0; i < size; i++)
    {
        if(score[i]<0 || score[i]>100)
        {
            throw InvalidScore();
        }
        else
            scores[i]=score[i];
    }
    cout << "The average of the test scores is " << average(score) << endl;
}

float TestScores::average(int score[])
{
    float avg=0;
    for(int i=0; i < size; i++)
    {
        avg=avg + score[i];
    }
    avg /= size;
    return avg;
}