
#include <cstdlib>
#include <iostream>

using namespace std;

#include "testScores.h"

int main(int argc, char** argv) {

    int score[5];
    cout << "Enter 5 test scores: ";
    for(int i=0; i<5; i++)
    {
        cin >> score[i];
    }
    try
    {
        TestScores student(score);
    }
    catch(TestScores::InvalidScore)
    {
        cout << "Error: Invalid score. The score has to be between 0 and 100.";
    }
    
    return 0;
}

