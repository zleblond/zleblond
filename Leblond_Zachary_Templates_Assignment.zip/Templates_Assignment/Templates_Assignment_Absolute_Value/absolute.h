
#ifndef ABSOLUTE_H
#define ABSOLUTE_H

template <class T>
T Absolute (T var)
{
    return abs(var);
}

#endif /* ABSOLUTE_H */

