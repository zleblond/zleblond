
#include <cstdlib>
#include <iostream>

using namespace std;

#include "absolute.h"

int main(int argc, char** argv) {

    int num, absVal;
    cout << "Enter value: ";
    cin >> num;
    absVal = Absolute(num);
    cout << "Absolute value of " << num << " is " << absVal << endl;
    
    return 0;
}

