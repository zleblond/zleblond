
#ifndef TIME_H
#define TIME_H
class Time
{
protected:
    int hour;
    int min;
    int sec;
public:
    Time()
    { hour=0; min=0; sec=0; }
    Time(int h, int m, int s)
    { hour=h; min=m; sec=s; }
    
    int getHour() const
    { return hour; }
    int getMin() const
    { return min; }
    int getSec() const
    { return sec;}
};

class MilTime: public Time
{
private:
    int mHours;
    int mSecs;
public:
    MilTime(int hours, int seconds)
    {
        mHours=hours;
        mSecs=seconds;
    }
    class InvalidHours
    { };
    class InvalidSecs
    { };
    void setTime(int, int);
    int getMHour();
    int getStandHr();
};

#endif /* TIME_H */

void MilTime::setTime(int milHour, int milSec)
{
    if(milHour<0 || milHour>2359)
    {
        throw InvalidHours();
    }
    else 
        mHours=milHour;
    
    if(milSec<0 || milSec>59)
    {
        throw InvalidSecs();
    }
    else
        mSecs=milSec;
    
    hour=(mHours/100);
    min=mHours%100;
    sec=mSecs;
}

int MilTime::getMHour()
{
    return mHours;
}

int MilTime::getStandHr()
{
    return hour%12;
}