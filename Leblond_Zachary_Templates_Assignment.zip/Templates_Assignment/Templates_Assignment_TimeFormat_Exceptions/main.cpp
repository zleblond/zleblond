
#include <cstdlib>
#include <iostream>

using namespace std;

#include "time.h"

int main(int argc, char** argv) {

    int hr, sec;
    MilTime time(0, 0);
    
    cout << "Enter time in military hours: ";
    cin >> hr;
    cout << "Enter military seconds: ";
    cin >> sec;
    try
    {
        time.setTime(hr, sec);
        cout << "Military Format: " << time.getHour() << "hrs: " << 
                time.getSec() << "sec" << endl;
        if(time.getHour() / 12==1)
        {
            cout << "Standard Format: " << time.getStandHr() << ": ";
            if(time.getMin()==0)
            {
                cout<<time.getMin()<<"0"<<":"<<time.getSec()<<"PM"<<endl;
            }
            else
                cout<<time.getMin()<<"PM"<<endl;
        }
        else
        {
            cout << "Standard Format: " << time.getStandHr()<<": ";
            if(time.getMin()==0)
            {
                cout<<time.getMin()<<"0"<<"AM"<<endl;
            }
            else
                cout << time.getMin()<<": "<<time.getSec()<<"AM"<<endl;
        }
    }
    catch(MilTime::InvalidHours)
    {
        cout<<"Military Time is from 0000-2359";
    }
    catch(MilTime::InvalidSecs)
    {
        cout << "Seconds range from 0-59";
    }
  
    return 0;
}

