
#include <cstdlib>
#include <iostream>

using namespace std;

#include "total.h"

int main(int argc, char** argv) {

    int n;
    cout << "How many values would you like to add up?: ";
    cin >> n;
    cout << "Total of all values: " << Total(n) << endl;
    
    return 0;
}

