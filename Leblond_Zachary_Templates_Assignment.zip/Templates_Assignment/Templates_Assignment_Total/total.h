
#ifndef TOTAL_H
#define TOTAL_H

template<class T>
T Total(T n)
{
    T total=0,num;
    int i=0;
    cout << "Enter values: ";
    while(i < n)
    {
        cin >> num;
        total=total + num;
        i++;
    }
    return total;
}


#endif /* TOTAL_H */

