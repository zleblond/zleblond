
#include <cstdlib>
#include <iostream>

using namespace std;

#include "intArray.h"

int main(int argc, char** argv) {

    const int size=10;
    IntArray table(size);
    
    for(int i=0; i<size; i++)
    {
        table[i] = i;
        cout << table[i];
        cout << endl;
    }
    
    try
    {
        table[size+1]=0;
    }
    catch(IntArray::subscriptExcep)
    {
        cout << "Error: Subscript is out of range." << endl;
    }
    
    return 0;
}

