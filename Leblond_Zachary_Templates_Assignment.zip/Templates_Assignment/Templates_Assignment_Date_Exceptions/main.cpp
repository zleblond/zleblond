
#include <cstdlib>
#include <iostream>

using namespace std;

#include "date.h"

int main(int argc, char** argv) {

    Date date;
    int day, month, year;
    cout << "Enter day: ";
    cin >> day;
    cout << "Enter month: ";
    cin >> month;
    cout << "Enter year: ";
    cin >> year;
    try
    {
        date.setDay(day);
        date.setMonth(month);
        date.setYear(year);
        date.format1();
        date.format2();
        date.format3();
    }
    catch(Date::InvalidDay)
    {
        cout << "There are only 30-31 days at most in a month" << endl;
    }
    catch(Date::InvalidMonth)
    {
        cout << "There are only 12 months in a year" << endl;
    }
    return 0;
}

