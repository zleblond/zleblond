
#ifndef DATE_H
#define DATE_H

class Date
{
private:
    int day;
    int month;
    int year;
public:
    Date()
    { day=0; month=0; year=0; }
    class InvalidDay
    { };
    class InvalidMonth
    { };
    void setDay(int);
    void setMonth(int);
    void setYear(int);
    int getDay();
    int getMonth();
    int getYear();
    
    void format1();
    void format2();
    void format3();
};

#endif /* DATE_H */

void Date::setDay(int d)
{
    if(d < 1 || d >31)
    {
        throw InvalidDay();
    }
    else 
        day=d;
}

void Date::setMonth(int m)
{
    if(m < 1 || m > 12)
    {
        throw InvalidMonth();
    }
    else
        month=m;
}

void Date::setYear(int y)
{
    year=y;
}

int Date::getDay()
{
    return day;
}

int Date::getMonth()
{
    return month;
}

int Date::getYear()
{
    return year;
}

void Date::format1()
{
    cout << month << "/" << day <<"/" << year << endl;
}

void Date::format2()
{
    switch(month)
    {
        case 1: cout << "January";break;
        case 2: cout << "February";break;
        case 3: cout << "March";break;
        case 4: cout << "April";break;
        case 5: cout << "May";break;
        case 6: cout << "June";break;
        case 7: cout << "July";break;
        case 8: cout << "August";break;
        case 9: cout << "September";break;
        case 10: cout<< "October";break;
        case 11: cout<< "November";break;
        case 12: cout<< "December";break;
    }
    cout << " " << day << ", " << year << endl;
}

void Date::format3()
{
    cout << day << " ";
    switch(month)
    {
        case 1: cout << "January";break;
        case 2: cout << "February";break;
        case 3: cout << "March";break;
        case 4: cout << "April";break;
        case 5: cout << "May";break;
        case 6: cout << "June";break;
        case 7: cout << "July";break;
        case 8: cout << "August";break;
        case 9: cout << "September";break;
        case 10: cout<< "October";break;
        case 11: cout<< "November";break;
        case 12: cout<< "December";break;
    }
    cout << " " << year << endl;
}