
#ifndef MAX_H
#define MAX_H

template <class T>
T Max(T param1, T param2)
{
    if(param1 > param2)
        return param1;
    else 
        return param2;
}

#endif /* MAX_H */

