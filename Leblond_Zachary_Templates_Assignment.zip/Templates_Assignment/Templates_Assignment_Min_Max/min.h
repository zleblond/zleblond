
#ifndef MIN_H
#define MIN_H
template <class T>
T Min(T param1, T param2)
{
    if(param1 < param2)
        return param1;
    else
        return param2;
}

#endif /* MIN_H */

