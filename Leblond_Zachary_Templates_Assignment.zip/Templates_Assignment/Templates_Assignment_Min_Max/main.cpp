
#include <cstdlib>
#include <iostream>

using namespace std;

#include "max.h"
#include "min.h"

int main(int argc, char** argv) {

    int num1, num2;
    int large, small;
    
    cout << "Enter first value: ";
    cin >> num1;
    cout << "Enter second value: ";
    cin >> num2;
    
    large = Max(num1, num2);
    small = Min(num1, num2);
    
    cout << "Largest of the two is: " << large << endl;
    cout << "Smallest of the two is: " << small << endl;
    
    return 0;
}

