
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

float total(vector<float>);
float avg(vector<float>);
float largest(vector<float>, int &);
float smallest(vector<float>, int &);

int main(int argc, char** argv) {

    const int months = 12;
    int sub=0;
    vector<float> rain;
    float num;
    for(int month = 0; month < months; month++)
    {
        cout << "Enter the rainfall in inches for month " << month + 1 << ": ";
        cin >> num;
        rain.push_back(num);
        while(rain[month] < 0)
        {
            cout << "You can't have a negative amount of rainfall. Please re "
                    "enter the correct amount of rainfall: ";
            cin >> rain[month];
        }
    }
    
    cout << fixed << showpoint << setprecision(2) << endl;
    cout << "The total amount of rainfall for the year is ";
    cout << total(rain) << " inches." << endl;
    
    cout << "The average rainfall for the year is ";
    cout << avg(rain) << " inches." << endl;
    
    cout << "The largest amount of rainfall for the year is ";
    cout << largest(rain, sub) << " inches." << endl;
    
    cout << "The smallest amount of rainfall for the year is " << 
            smallest(rain, sub) << " inches.";
}

float total(vector<float> rain)
{
    float total = 0;
    for(int count = 0; count < 12; count++)
    {
        total+= rain[count];
    }
    return total;
}

float avg(vector<float> rain)
{
    float avg = 0;
    avg = total(rain) / 12;
    return avg;
}

float largest(vector<float> rain, int &sub)
{
    float largest;
    largest=rain[0];
    for(int month=0; month < 12; month++)
    {
        if(rain[month] > largest)
        {
            largest = rain[month];
            sub = month;
        }
    }
    return largest;
}

float smallest(vector<float> rain, int &sub)
{
    float smallest;
    smallest = rain[0];
    for(int month = 0; month < 12; month++)
    {
        if(rain[month] < smallest)
        {
            smallest = rain[month];
            sub = month;
        }
    }
    return smallest;
}