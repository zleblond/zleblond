
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

bool bSearch(vector<int>, int, int);

int main(int argc, char** argv) {

    const int size = 18;
    int num;
    
    int tests[size] = {5658845, 450125, 7895122, 8777541, 8451277, 1302850, 
                       8080152, 4562555, 5552012, 5050552, 7825877, 1250255, 
                       1005231, 654231, 3852085, 7576651, 7881200, 4581002};
    vector<int> accounts;
    bool result;
    for(int i = 0; i < 18; i++)
    {
        accounts.push_back(tests[i]);
    }
    cout << "Enter number to search: ";
    cin >> num;

    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < size - 1; j++)
        {
            if(accounts.at(j) > accounts.at(j+1))
            {
                int temp=accounts.at(j);
                accounts.at(j)=accounts.at(j+1);
                accounts.at(j+1)=temp;
            }
        }
    }
    result = bSearch(accounts, size, num);
    if(result == true)
    {
        cout << "You entered a valid number" << endl;
    }
    else
    {
        cout << "You entered an invalid number" << endl;
    }
    return 0;
}

bool bSearch(vector<int> array, int numElem, int val)
{
    int first=0;
    int last = numElem - 1;
    int middle;
    bool found = false;
    while(!found && first <= last)
    {
        middle = (first + last) / 2;
        if(array.at(middle) ==  val)
        {
            found = true;
        }
        else if(array.at(middle) > val)
        {
            last = middle - 1;
        }
        else
        {
            first = middle + 1;
        }
    }
    return found;
}