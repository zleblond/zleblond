
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

float average(vector<int>, int);
void sort(vector<int>, int);

int main(int argc, char** argv) {

    vector<int> testScores;
    float avgScore, score;
    int num, i, temp;
    
    cout << "Enter number of test scores to be input: ";
    cin >> num;
    
    cout << "Enter test scores: ";
    for(int i = 0; i < num; i++)
    {
        cin >> score;
        testScores.push_back(score);
    }
    //Sort
    for(int i = 0; i < num; i++)
    {
        for(int j = 0; j < num - 1; j++)
        {
            if(testScores[j] > testScores[j+1])
            {
                temp = testScores[j];
                testScores[j] = testScores[j+1];
                testScores[j+1] = temp;
            }
        }
    }
    //End sort
    cout << "Sorted Test Scores: " << endl;
    for(int i = 0; i < num; i++)
    {
        cout << testScores.at(i) << " ";
    }
    
    avgScore = average(testScores, num);
    cout << "\nAverage test score is: " << avgScore << endl;
    return 0;
}

float average(vector<int> scores, int number)
{
    float avg = 0;
    for(int i = 0; i < number; i++)
    {
        avg+=scores.at(i);
    }
    avg=avg/number;
    return avg;
}
